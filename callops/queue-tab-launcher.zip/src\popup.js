/**
 * popup.js — Queue Tab Launcher v1.4
 * @author Ignacio
 * @built-with Claude Sonnet 4.6 (Anthropic)
 */

// ── DOM refs ──────────────────────────────────────────────────────────
const fileInput    = document.getElementById("fileInput");
const dropZone     = document.getElementById("dropZone");
const statusDot    = document.getElementById("statusDot");
const stripText    = document.getElementById("stripText");
const queueBtns    = document.getElementById("queueBtns");
const btnCallNotes = document.getElementById("btnCallNotes");
const btnVerify    = document.getElementById("btnVerify");
const btnReconfig  = document.getElementById("btnReconfig");
const btnClear     = document.getElementById("btnClear");
const tplJson      = document.getElementById("tplJson");
const tplCsv       = document.getElementById("tplCsv");
const logBox       = document.getElementById("logBox");
const toast        = document.getElementById("toast");
const opView       = document.getElementById("opView");
const setupView    = document.getElementById("setupView");

// ── View helpers ──────────────────────────────────────────────────────
function showOpView()    { opView.style.display = "flex";   setupView.style.display = "none"; }
function showSetupView() { opView.style.display = "none";   setupView.style.display = "flex"; }

// ── Init ──────────────────────────────────────────────────────────────
(async function init() {
  const { config } = await chrome.storage.local.get("config");
  if (config) {
    renderLoadedConfig(config);
  } else {
    showSetupView();
  }
  loadLogs();
  checkFileAccess();
})();

async function checkFileAccess() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab?.url?.startsWith("file://")) {
    document.getElementById("fileWarn").classList.add("show");
  }
}

document.getElementById("goExtSettings").addEventListener("click", () => {
  chrome.tabs.create({ url: `chrome://extensions/?id=${chrome.runtime.id}` });
});

// Relay de logs desde el background
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "LOG") appendLog(msg.level, msg.text);
});

// ── Drag & drop ───────────────────────────────────────────────────────
dropZone.addEventListener("dragover", (e) => {
  e.preventDefault();
  dropZone.classList.add("dragover");
});
dropZone.addEventListener("dragleave", () => dropZone.classList.remove("dragover"));
dropZone.addEventListener("drop", (e) => {
  e.preventDefault();
  dropZone.classList.remove("dragover");
  const file = e.dataTransfer.files[0];
  if (file) processFile(file);
});
fileInput.addEventListener("change", () => {
  if (fileInput.files[0]) processFile(fileInput.files[0]);
});

// ── File processing ───────────────────────────────────────────────────
async function processFile(file) {
  const ext  = file.name.split(".").pop().toLowerCase();
  const text = await file.text();
  let config = null;

  try {
    if (ext === "json") {
      config = JSON.parse(text);
    } else if (ext === "csv") {
      config = parseCSV(text);
    } else {
      showToast("Formato no soportado (.json o .csv)", "err");
      return;
    }

    const err = validateConfig(config);
    if (err) { showToast(err, "err"); appendLog("err", err); return; }

    await chrome.storage.local.set({ config });
    renderLoadedConfig(config);
    appendLog("ok", `Config cargada: "${file.name}" — ${config.queues.length} cola(s)`);
    showToast("✓ Configuración cargada", "ok");

  } catch (e) {
    showToast("Error al parsear el archivo", "err");
    appendLog("err", e.message);
  }
}

// ── Config validation ─────────────────────────────────────────────────
function validateConfig(c) {
  if (!c.selector) return "Falta campo 'selector'";
  if (!Array.isArray(c.queues) || c.queues.length === 0) return "Falta campo 'queues' (array)";
  for (const q of c.queues) {
    if (!q.name) return "Una cola no tiene campo 'name'";
    if (!Array.isArray(q.tabs) || q.tabs.length === 0) return `Cola "${q.name}" no tiene 'tabs'`;
    for (const t of q.tabs) {
      if (!t.url) return `Una pestaña de "${q.name}" no tiene 'url'`;
    }
  }
  return null;
}

// ── Render config cargada ─────────────────────────────────────────────
function renderLoadedConfig(config) {
  statusDot.className = "status-dot active";

  stripText.innerHTML = `Observando: <span style="color:var(--accent2)">${config.selector}</span>`;

  queueBtns.innerHTML = "";
  for (const q of config.queues) {
    const tabCount = q.tabs.length;
    const btn = document.createElement("button");
    btn.className = "queue-launch-btn";
    btn.innerHTML = `
      <div>
        <div class="queue-launch-btn-name">${q.name}</div>
        <div class="queue-launch-btn-meta">${tabCount} pestaña${tabCount !== 1 ? "s" : ""}</div>
      </div>
      <span class="queue-launch-btn-arrow">▶</span>
    `;
    btn.addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: "OPEN_QUEUE_TABS", queueName: q.name });
      appendLog("ok", `Abriendo manualmente: "${q.name}"`);
      showToast(`Abriendo: ${q.name}`, "ok");
    });
    queueBtns.appendChild(btn);
  }

  showOpView();
}

// ── Call Notes ────────────────────────────────────────────────────────
btnCallNotes.addEventListener("click", async () => {
  const { config } = await chrome.storage.local.get("config");
  if (!config?.call_notes_url) {
    showToast("call_notes_url no configurado", "warn");
    appendLog("warn", "call_notes_url no definido en config");
    return;
  }
  chrome.tabs.create({ url: config.call_notes_url });
});

// ── Verificar ─────────────────────────────────────────────────────────
btnVerify.addEventListener("click", async () => {
  btnVerify.textContent = "...";
  btnVerify.disabled    = true;

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) throw new Error("no tab");

    const response = await chrome.tabs.sendMessage(tab.id, { type: "QTL_PING" });

    if (response?.ok) {
      const listening = response.listening ? "escuchando" : "inyectado (sin config)";
      btnVerify.textContent = "✓ Activo";
      showToast("✓ Script activo en esta pestaña", "ok");
      let host = tab.url;
      try { host = new URL(tab.url).hostname || tab.url; } catch {}
      appendLog("ok", `Content script ${listening}: ${host}`);
    } else {
      throw new Error("bad response");
    }

  } catch {
    btnVerify.textContent = "⚠ Sin respuesta";
    showToast("⚠ Refrescá la pestaña del sistema", "warn");
    appendLog("warn", "Sin respuesta — refrescá la pestaña del sistema");
  }

  setTimeout(() => {
    btnVerify.textContent = "Verificar";
    btnVerify.disabled    = false;
  }, 2500);
});

// ── Reconfig ──────────────────────────────────────────────────────────
btnReconfig.addEventListener("click", () => {
  showSetupView();
  appendLog("warn", "Modo reconfiguración activo.");
});

// ── Clear ─────────────────────────────────────────────────────────────
btnClear.addEventListener("click", async () => {
  await chrome.storage.local.remove("config");
  statusDot.className = "status-dot";
  showSetupView();
  appendLog("warn", "Configuración eliminada.");
  showToast("Configuración eliminada", "");
});

// ── Template downloads ────────────────────────────────────────────────
tplJson.addEventListener("click", () => {
  const template = {
    selector: ".queue-name-selector",
    call_notes_url: "file:///C:/ruta/a/call-notes.html",
    queues: [
      {
        name: "Cola Ventas",
        campaign: "VENTAS_Q1",
        tabs: [
          { url: "https://sistema.empresa.com/gestion", active: true },
          { url: "https://sistema.empresa.com/campana/ventas", active: false },
          { url: "https://crm.empresa.com/cliente", active: false },
        ],
      },
      {
        name: "Cola Soporte",
        campaign: "SOPORTE_GENERAL",
        tabs: [
          { url: "https://sistema.empresa.com/gestion", active: true },
          { url: "https://sistema.empresa.com/campana/soporte", active: false },
          { url: "https://crm.empresa.com/tickets", active: false },
        ],
      },
    ],
  };
  downloadFile("qtl-config.json", JSON.stringify(template, null, 2), "application/json");
});

tplCsv.addEventListener("click", () => {
  const csv = [
    "queue_name,campaign,tab1_url,tab1_active,tab2_url,tab2_active,tab3_url,tab3_active,selector",
    "Cola Ventas,VENTAS_Q1,https://sistema.empresa.com/gestion,true,https://sistema.empresa.com/campana/ventas,false,https://crm.empresa.com/cliente,false,.queue-name-selector",
    "Cola Soporte,SOPORTE_GENERAL,https://sistema.empresa.com/gestion,true,https://sistema.empresa.com/campana/soporte,false,https://crm.empresa.com/tickets,false,.queue-name-selector",
  ].join("\n");
  downloadFile("qtl-config.csv", csv, "text/csv");
});

// ── CSV parser ────────────────────────────────────────────────────────
function parseCSV(text) {
  const lines = text.trim().split("\n").filter(Boolean);
  if (lines.length < 2) throw new Error("CSV vacío o sin filas de datos");

  const headers = lines[0].split(",").map((h) => h.trim());
  const rows    = lines.slice(1);
  let selector  = "";

  const queues = rows.map((line) => {
    const vals = line.split(",").map((v) => v.trim());
    const row  = {};
    headers.forEach((h, i) => (row[h] = vals[i] || ""));
    if (!selector && row.selector) selector = row.selector;

    const tabs = [];
    for (let i = 1; i <= 5; i++) {
      if (row[`tab${i}_url`]) {
        tabs.push({ url: row[`tab${i}_url`], active: row[`tab${i}_active`] === "true" });
      }
    }
    return { name: row.queue_name, campaign: row.campaign, tabs };
  });

  return { selector, queues };
}

// ── Log system ────────────────────────────────────────────────────────
const MAX_LOGS = 20;

async function loadLogs() {
  const { logs } = await chrome.storage.local.get("logs");
  if (logs?.length) {
    logBox.innerHTML = "";
    logs.forEach((l) => renderLog(l.level, l.text, l.time));
  }
}

function appendLog(level, text) {
  const entry = { level, text, time: new Date().toLocaleTimeString("es-UY") };
  renderLog(entry.level, entry.text, entry.time);
  chrome.storage.local.get("logs", ({ logs = [] }) => {
    chrome.storage.local.set({ logs: [...logs, entry].slice(-MAX_LOGS) });
  });
}

function renderLog(level, text, time) {
  const span = document.createElement("span");
  span.className  = `log-line log-${level}`;
  span.textContent = `[${time}] ${text}`;
  logBox.appendChild(span);
  if (logBox.children.length > MAX_LOGS) logBox.removeChild(logBox.firstChild);
  logBox.scrollTop = logBox.scrollHeight;
}

// ── Toast ─────────────────────────────────────────────────────────────
let toastTimer;
function showToast(msg, type) {
  toast.textContent = msg;
  toast.className   = `show ${type}`;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (toast.className = ""), 2500);
}

// ── Download helper ───────────────────────────────────────────────────
function downloadFile(filename, content, mimeType) {
  const blob = new Blob([content], { type: mimeType });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement("a");
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}
