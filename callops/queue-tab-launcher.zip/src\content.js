/**
 * content.js — Queue Tab Launcher v1.3
 * Observa el DOM del sistema de llamadas.
 * Captura: cola, teléfono, nombre del cliente.
 *
 * @author Ignacio
 * @built-with Claude Sonnet 4.6 (Anthropic)
 */

const IGNORED_VALUES = ["sin llamada", "— —", "", "sin cola", "null", "undefined", "—"];
const COOLDOWN_MS = 4000;

let lastQueue      = null;
let lastTriggerTime = 0;
let config         = null;
let observer       = null;
let intervalId     = null;

// Al cargar la página: leer config existente
init();

// Reaccionar inmediatamente cuando el usuario carga/cambia la config en el popup,
// sin esperar ningún retry loop
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.config) {
    const newConfig = changes.config.newValue;
    if (newConfig?.selector) {
      config = newConfig;
      console.log(`[QTL] Config actualizada. Iniciando escucha: "${config.selector}"`);
      startListening();
    } else {
      // Config eliminada: detener escucha
      config = null;
      if (observer)    { observer.disconnect(); observer = null; }
      if (intervalId)  { clearInterval(intervalId); intervalId = null; }
      lastQueue = null;
      console.log("[QTL] Config eliminada. Escucha detenida.");
    }
  }
});

async function init() {
  const result = await chrome.storage.local.get("config");
  config = result.config;

  if (!config?.selector) {
    console.log("[QTL] Sin config — esperando que se cargue via popup.");
    return; // onChanged se encarga cuando el usuario cargue la config
  }

  startListening();
}

function startListening() {
  // Capturar valor actual del DOM para no disparar al arrancar
  const initial = readText(config.selector);
  if (initial && !IGNORED_VALUES.includes(initial.toLowerCase())) {
    lastQueue = initial;
  }

  startObserver();

  // Evitar intervalos duplicados si se reinicializa
  if (intervalId) clearInterval(intervalId);
  intervalId = setInterval(checkForNewCall, 1500);

  console.log(`[QTL] Escuchando: "${config.selector}"`);
}

// ── Leer texto de un selector ──────────────────────────────────────────
function readText(selector) {
  if (!selector) return null;
  const el = document.querySelector(selector);
  if (!el) return null;
  return (el.textContent || el.innerText || el.value || "").trim();
}

// ── Detectar nueva llamada ─────────────────────────────────────────────
function checkForNewCall() {
  const currentQueue = readText(config?.selector);
  const now = Date.now();

  if (!currentQueue) return;

  if (IGNORED_VALUES.includes(currentQueue.toLowerCase())) {
    if (lastQueue !== null) {
      console.log("[QTL] Llamada finalizada, reseteando.");
      lastQueue = null;
    }
    return;
  }

  if (currentQueue !== lastQueue && now - lastTriggerTime > COOLDOWN_MS) {
    lastQueue = currentQueue;
    lastTriggerTime = now;

    const phone = config.phone_selector ? readText(config.phone_selector) : null;
    const name  = config.name_selector  ? readText(config.name_selector)  : null;

    console.log(`[QTL] Cola: "${currentQueue}" | Tel: "${phone}" | Nombre: "${name}"`);

    chrome.runtime.sendMessage({
      type: "QUEUE_DETECTED",
      queueName: currentQueue,
      phone: phone || null,
      callerName: name || null,
    }).catch(() => {
      setTimeout(() => {
        chrome.runtime.sendMessage({
          type: "QUEUE_DETECTED",
          queueName: currentQueue,
          phone: phone || null,
          callerName: name || null,
        }).catch(() => {});
      }, 500);
    });
  }
}

function startObserver() {
  if (observer) observer.disconnect();
  observer = new MutationObserver(() => checkForNewCall());
  observer.observe(document.body, {
    childList: true, subtree: true, characterData: true,
  });
}

// ── Relay de inyección: background → content → página ─────────────────
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "QTL_PING") {
    sendResponse({ ok: true, listening: !!config });
    return true;
  }

  if (message.type === "QTL_INJECT_CALL") {
    window.postMessage({
      type: "QTL_NEW_CALL",
      queue: message.queue || null,
      phone: message.phone || null,
      name:  message.name  || null,
    }, "*");
    sendResponse({ ok: true });
  }
});
