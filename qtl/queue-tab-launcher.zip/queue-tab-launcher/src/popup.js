/**
 * popup.js — Queue Tab Launcher v1.1
 * @author Ignacio
 * @built-with Claude Sonnet 4.6 (Anthropic)
 */

// popup.js

// ── DOM refs ──────────────────────────────────────────────────────────
const fileInput    = document.getElementById("fileInput");
const dropZone     = document.getElementById("dropZone");
const statusDot    = document.getElementById("statusDot");
const statusCard   = document.getElementById("statusCard");
const statusTitle  = document.getElementById("statusTitle");
const statusDesc   = document.getElementById("statusDesc");
const configPreview= document.getElementById("configPreview");
const btnTest      = document.getElementById("btnTest");
const btnClear     = document.getElementById("btnClear");
const tplJson      = document.getElementById("tplJson");
const tplCsv       = document.getElementById("tplCsv");
const logBox       = document.getElementById("logBox");
const toast        = document.getElementById("toast");

// ── Init ──────────────────────────────────────────────────────────────
(async function init() {
  const { config } = await chrome.storage.local.get("config");
  if (config) renderLoadedConfig(config);
  loadLogs();
  checkFileAccess();
})();

async function checkFileAccess() {
  // Chequear si la pestaña activa es file://
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab?.url?.startsWith("file://")) {
    document.getElementById("fileWarn").classList.add("show");
  }
}

document.getElementById("goExtSettings").addEventListener("click", () => {
  chrome.tabs.create({ url: `chrome://extensions/?id=${chrome.runtime.id}` });
});

// Escuchar logs del background
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "LOG") appendLog(msg.level, msg.text);
});

// ── Drag & drop ───────────────────────────────────────────────────────
dropZone.addEventListener("dragover", (e) => {
  e.preventDefault();
  dropZone.classList.add("dragover");
});
dropZone.addEventListener("dragleave", () => dropZone.classList.remove("dragover"));
dropZone.addEventListener("drop", (e) => {
  e.preventDefault();
  dropZone.classList.remove("dragover");
  const file = e.dataTransfer.files[0];
  if (file) processFile(file);
});
fileInput.addEventListener("change", () => {
  if (fileInput.files[0]) processFile(fileInput.files[0]);
});

// ── File processing ───────────────────────────────────────────────────
async function processFile(file) {
  const ext = file.name.split(".").pop().toLowerCase();
  const text = await file.text();
  let config = null;

  try {
    if (ext === "json") {
      config = JSON.parse(text);
    } else if (ext === "csv") {
      config = parseCSV(text);
    } else {
      showToast("Formato no soportado (.json o .csv)", "err");
      return;
    }

    const err = validateConfig(config);
    if (err) {
      showToast(err, "err");
      appendLog("err", err);
      return;
    }

    await chrome.storage.local.set({ config });
    renderLoadedConfig(config);
    appendLog("ok", `Config cargada: "${file.name}" — ${config.queues.length} cola(s)`);
    showToast("✓ Configuración cargada", "ok");

  } catch (e) {
    showToast("Error al parsear el archivo", "err");
    appendLog("err", e.message);
  }
}

// ── Config validation ─────────────────────────────────────────────────
function validateConfig(c) {
  if (!c.selector) return "Falta campo 'selector'";
  if (!Array.isArray(c.queues) || c.queues.length === 0)
    return "Falta campo 'queues' (array)";
  for (const q of c.queues) {
    if (!q.name) return `Una cola no tiene campo 'name'`;
    if (!Array.isArray(q.tabs) || q.tabs.length === 0)
      return `Cola "${q.name}" no tiene 'tabs'`;
    for (const t of q.tabs) {
      if (!t.url) return `Una pestaña de "${q.name}" no tiene 'url'`;
    }
  }
  return null;
}

// ── Render loaded config ──────────────────────────────────────────────
function renderLoadedConfig(config) {
  statusDot.className = "status-dot active";
  statusTitle.textContent = "Configuración activa";
  statusDesc.textContent = `Observando: ${config.selector}`;
  configPreview.innerHTML = "";

  // Mostrar tags de colas
  for (const q of config.queues) {
    const tag = document.createElement("span");
    tag.className = "tag accent";
    tag.textContent = q.name;
    configPreview.appendChild(tag);
  }

  const totalTabs = config.queues.reduce((acc, q) => acc + q.tabs.length, 0);
  const infoTag = document.createElement("span");
  infoTag.className = "tag success";
  infoTag.textContent = `${totalTabs} tabs totales`;
  configPreview.appendChild(infoTag);

  btnTest.disabled = false;
}

// ── Test button ───────────────────────────────────────────────────────
btnTest.addEventListener("click", async () => {
  const { config } = await chrome.storage.local.get("config");
  if (!config) return;

  const firstQueue = config.queues[0];
  appendLog("warn", `Test: simulando cola "${firstQueue.name}"...`);
  chrome.runtime.sendMessage({
    type: "QUEUE_DETECTED",
    queueName: firstQueue.name,
  });
  showToast(`Probando cola: "${firstQueue.name}"`, "ok");
});

// ── Clear button ──────────────────────────────────────────────────────
btnClear.addEventListener("click", async () => {
  await chrome.storage.local.remove("config");
  statusDot.className = "status-dot";
  statusTitle.textContent = "Sin configuración";
  statusDesc.textContent = "Cargá un archivo JSON para activar la extensión.";
  configPreview.innerHTML = "";
  btnTest.disabled = true;
  appendLog("warn", "Configuración eliminada.");
  showToast("Configuración eliminada", "");
});

// ── Template downloads ────────────────────────────────────────────────
tplJson.addEventListener("click", () => {
  const template = {
    selector: ".queue-name-selector",
    queues: [
      {
        name: "Cola Ventas",
        campaign: "VENTAS_Q1",
        tabs: [
          { url: "https://sistema.empresa.com/nueva-tarea", active: true },
          { url: "https://sistema.empresa.com/campana/ventas", active: false },
          { url: "https://crm.empresa.com/cliente", active: false }
        ]
      },
      {
        name: "Cola Soporte",
        campaign: "SOPORTE_GENERAL",
        tabs: [
          { url: "https://sistema.empresa.com/nueva-tarea", active: true },
          { url: "https://sistema.empresa.com/campana/soporte", active: false },
          { url: "https://crm.empresa.com/tickets", active: false }
        ]
      }
    ]
  };
  downloadFile(
    "qtl-config.json",
    JSON.stringify(template, null, 2),
    "application/json"
  );
});

tplCsv.addEventListener("click", () => {
  const csv = [
    "queue_name,campaign,tab1_url,tab1_active,tab2_url,tab2_active,tab3_url,tab3_active,selector",
    "Cola Ventas,VENTAS_Q1,https://sistema.empresa.com/nueva-tarea,true,https://sistema.empresa.com/campana/ventas,false,https://crm.empresa.com/cliente,false,.queue-name-selector",
    "Cola Soporte,SOPORTE_GENERAL,https://sistema.empresa.com/nueva-tarea,true,https://sistema.empresa.com/campana/soporte,false,https://crm.empresa.com/tickets,false,.queue-name-selector"
  ].join("\n");
  downloadFile("qtl-config.csv", csv, "text/csv");
});

// ── CSV parser ────────────────────────────────────────────────────────
function parseCSV(text) {
  const lines = text.trim().split("\n").filter(Boolean);
  if (lines.length < 2) throw new Error("CSV vacío o sin filas de datos");

  const headers = lines[0].split(",").map((h) => h.trim());
  const rows = lines.slice(1);

  let selector = "";
  const queues = rows.map((line) => {
    const vals = line.split(",").map((v) => v.trim());
    const row = {};
    headers.forEach((h, i) => (row[h] = vals[i] || ""));

    if (!selector && row.selector) selector = row.selector;

    const tabs = [];
    for (let i = 1; i <= 5; i++) {
      if (row[`tab${i}_url`]) {
        tabs.push({
          url: row[`tab${i}_url`],
          active: row[`tab${i}_active`] === "true",
        });
      }
    }

    return {
      name: row.queue_name,
      campaign: row.campaign,
      tabs,
    };
  });

  return { selector, queues };
}

// ── Log system ────────────────────────────────────────────────────────
const MAX_LOGS = 20;

async function loadLogs() {
  const { logs } = await chrome.storage.local.get("logs");
  if (logs && logs.length) {
    logBox.innerHTML = "";
    logs.forEach((l) => renderLog(l.level, l.text, l.time));
  }
}

function appendLog(level, text) {
  const entry = { level, text, time: new Date().toLocaleTimeString("es-UY") };
  renderLog(entry.level, entry.text, entry.time);

  // Persistir logs
  chrome.storage.local.get("logs", ({ logs = [] }) => {
    const updated = [...logs, entry].slice(-MAX_LOGS);
    chrome.storage.local.set({ logs: updated });
  });
}

function renderLog(level, text, time) {
  const span = document.createElement("span");
  span.className = `log-line log-${level}`;
  span.textContent = `[${time}] ${text}`;
  logBox.appendChild(span);

  if (logBox.children.length > MAX_LOGS) {
    logBox.removeChild(logBox.firstChild);
  }
  logBox.scrollTop = logBox.scrollHeight;
}

// ── Toast ─────────────────────────────────────────────────────────────
let toastTimer;
function showToast(msg, type) {
  toast.textContent = msg;
  toast.className = `show ${type}`;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (toast.className = ""), 2500);
}

// ── Download helper ───────────────────────────────────────────────────
function downloadFile(filename, content, mimeType) {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
