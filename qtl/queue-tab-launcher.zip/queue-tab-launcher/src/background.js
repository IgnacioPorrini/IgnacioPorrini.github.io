/**
 * background.js — Queue Tab Launcher v1.1
 * Service Worker: gestiona la apertura de pestañas por cola.
 *
 * @author Ignacio
 * @built-with Claude Sonnet 4.6 (Anthropic)
 */

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "QUEUE_DETECTED") {
    handleQueueDetected(message.queueName, sender.tab);
    sendResponse({ ok: true });
  }
  if (message.type === "OPEN_TABS") {
    openTabs(message.tabs);
    sendResponse({ ok: true });
  }
  return true;
});

async function handleQueueDetected(queueName, sourceTab) {
  const { config } = await chrome.storage.local.get("config");
  if (!config) {
    console.warn("[QTL] Sin configuración.");
    return;
  }

  const queueConfig = config.queues.find(
    (q) => q.name.trim().toLowerCase() === queueName.trim().toLowerCase()
  );

  if (!queueConfig) {
    console.warn(`[QTL] Cola no mapeada: "${queueName}"`);
    notifyPopup({ type: "LOG", level: "warn", text: `Cola no mapeada: "${queueName}"` });
    if (config.default_tabs) {
      showBannerOnTab(sourceTab, queueName, null, config.default_tabs);
    }
    return;
  }

  console.log(`[QTL] Cola: "${queueName}" → mostrando banner`);
  notifyPopup({ type: "LOG", level: "ok", text: `Cola detectada: "${queueName}"` });
  showBannerOnTab(sourceTab, queueName, queueConfig.campaign, queueConfig.tabs);
}

async function showBannerOnTab(tab, queueName, campaign, tabs) {
  if (!tab?.id) return;
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: injectBanner,
      args: [queueName, campaign, tabs],
    });
  } catch (e) {
    console.error("[QTL] Error inyectando banner:", e);
    openTabs(tabs);
  }
}

// Se ejecuta en la página — sin referencias a marcas
function injectBanner(queueName, campaign, tabs) {
  const existing = document.getElementById("qtl-banner");
  if (existing) existing.remove();

  const banner = document.createElement("div");
  banner.id = "qtl-banner";
  banner.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 999999;
    width: 300px;
    background: #1a1a1a;
    border: 1px solid #333;
    border-left: 3px solid #4f8ef7;
    border-radius: 10px;
    box-shadow: 0 8px 32px rgba(0,0,0,0.4);
    font-family: 'IBM Plex Mono', 'Courier New', monospace;
    overflow: hidden;
    animation: qtl-slide-in 0.3s ease;
  `;

  banner.innerHTML = `
    <style>
      @keyframes qtl-slide-in {
        from { opacity: 0; transform: translateX(20px); }
        to   { opacity: 1; transform: translateX(0); }
      }
      #qtl-banner * { box-sizing: border-box; margin: 0; padding: 0; }
      #qtl-banner .qtl-head {
        padding: 12px 14px 8px;
        display: flex;
        align-items: center;
        justify-content: space-between;
      }
      #qtl-banner .qtl-logo {
        font-size: 10px;
        letter-spacing: 0.1em;
        color: #4f8ef7;
        text-transform: uppercase;
        font-weight: 600;
      }
      #qtl-banner .qtl-close {
        background: none; border: none; color: #555;
        font-size: 14px; cursor: pointer; padding: 0 2px; line-height: 1;
      }
      #qtl-banner .qtl-close:hover { color: #aaa; }
      #qtl-banner .qtl-body { padding: 0 14px 14px; }
      #qtl-banner .qtl-queue {
        font-size: 16px; font-weight: 600; color: #f0ede8;
        margin-bottom: 3px; letter-spacing: -0.02em;
      }
      #qtl-banner .qtl-campaign { font-size: 10px; color: #666; margin-bottom: 12px; }
      #qtl-banner .qtl-tabs { margin-bottom: 12px; }
      #qtl-banner .qtl-tab-row {
        display: flex; align-items: center; gap: 6px;
        padding: 4px 0; font-size: 10px; color: #666;
        border-bottom: 1px solid #222;
      }
      #qtl-banner .qtl-tab-row:last-child { border-bottom: none; }
      #qtl-banner .qtl-tab-dot {
        width: 5px; height: 5px; border-radius: 50%;
        background: #4f8ef7; flex-shrink: 0;
      }
      #qtl-banner .qtl-tab-url {
        overflow: hidden; text-overflow: ellipsis;
        white-space: nowrap; color: #555; max-width: 220px;
      }
      #qtl-banner .qtl-btn-row { display: flex; gap: 6px; }
      #qtl-banner .qtl-btn {
        flex: 1; padding: 8px 0; border-radius: 6px; border: none;
        font-family: inherit; font-size: 11px; font-weight: 600;
        cursor: pointer; letter-spacing: 0.03em; transition: filter 0.15s;
      }
      #qtl-banner .qtl-btn:hover { filter: brightness(1.15); }
      #qtl-banner .qtl-open { background: #4f8ef7; color: white; }
      #qtl-banner .qtl-dismiss { background: #2a2a2a; color: #666; border: 1px solid #333; }
    </style>

    <div class="qtl-head">
      <span class="qtl-logo">📋 Llamada entrante</span>
      <button class="qtl-close" id="qtl-close">✕</button>
    </div>
    <div class="qtl-body">
      <div class="qtl-queue">${queueName}</div>
      <div class="qtl-campaign">${campaign ? `Campaña: ${campaign}` : 'Cola detectada'}</div>
      <div class="qtl-tabs">
        ${tabs.map(t => `
          <div class="qtl-tab-row">
            <span class="qtl-tab-dot"></span>
            <span class="qtl-tab-url">${t.url}</span>
          </div>
        `).join('')}
      </div>
      <div class="qtl-btn-row">
        <button class="qtl-btn qtl-open" id="qtl-open">▶ Abrir pestañas</button>
        <button class="qtl-btn qtl-dismiss" id="qtl-dismiss">Ignorar</button>
      </div>
    </div>
  `;

  document.body.appendChild(banner);

  const autoClose = setTimeout(() => banner.remove(), 30000);

  document.getElementById("qtl-close").onclick = () => { clearTimeout(autoClose); banner.remove(); };
  document.getElementById("qtl-dismiss").onclick = () => { clearTimeout(autoClose); banner.remove(); };
  document.getElementById("qtl-open").onclick = () => {
    clearTimeout(autoClose);
    banner.remove();
    chrome.runtime.sendMessage({ type: "OPEN_TABS", tabs });
  };
}

async function openTabs(tabs) {
  for (const tabConfig of tabs) {
    await chrome.tabs.create({ url: tabConfig.url, active: tabConfig.active === true });
    await sleep(300);
  }
  notifyPopup({ type: "LOG", level: "ok", text: `${tabs.length} pestañas abiertas` });
}

function notifyPopup(msg) {
  chrome.runtime.sendMessage(msg).catch(() => {});
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

console.log("[QTL] Queue Tab Launcher activo v1.1");
