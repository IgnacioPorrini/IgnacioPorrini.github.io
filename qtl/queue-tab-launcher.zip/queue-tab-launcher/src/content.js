/**
 * content.js — Queue Tab Launcher v1.1
 * Observa el DOM del sistema de llamadas y detecta colas entrantes.
 *
 * @author Ignacio
 * @built-with Claude Sonnet 4.6 (Anthropic)
 */

const IGNORED_VALUES = ["sin llamada", "— —", "", "sin cola", "null", "undefined"];
const COOLDOWN_MS = 4000;

let lastQueue = null;
let lastTriggerTime = 0;
let config = null;
let observer = null;

init();

async function init() {
  const result = await chrome.storage.local.get("config");
  config = result.config;

  if (!config || !config.selector) {
    console.log("[QTL] Sin config cargada, esperando...");
    setTimeout(init, 3000);
    return;
  }

  console.log(`[QTL] Activo. Selector: "${config.selector}"`);

  const initial = readQueueName();
  if (initial && !IGNORED_VALUES.includes(initial.toLowerCase())) {
    lastQueue = initial;
    console.log(`[QTL] Valor inicial ignorado: "${initial}"`);
  }

  startObserver();
  setInterval(checkForNewCall, 1500);
}

function readQueueName() {
  if (!config?.selector) return null;
  const el = document.querySelector(config.selector);
  if (!el) return null;
  return (el.textContent || el.innerText || el.value || "").trim();
}

function checkForNewCall() {
  const currentQueue = readQueueName();
  const now = Date.now();

  if (!currentQueue) return;

  if (IGNORED_VALUES.includes(currentQueue.toLowerCase())) {
    if (lastQueue !== null) {
      console.log("[QTL] Llamada finalizada, reseteando.");
      lastQueue = null;
    }
    return;
  }

  if (currentQueue !== lastQueue && now - lastTriggerTime > COOLDOWN_MS) {
    lastQueue = currentQueue;
    lastTriggerTime = now;
    console.log(`[QTL] Cola detectada: "${currentQueue}"`);
    chrome.runtime.sendMessage({
      type: "QUEUE_DETECTED",
      queueName: currentQueue,
    }).catch(() => {
      setTimeout(() => {
        chrome.runtime.sendMessage({ type: "QUEUE_DETECTED", queueName: currentQueue }).catch(() => {});
      }, 500);
    });
  }
}

function startObserver() {
  if (observer) observer.disconnect();
  observer = new MutationObserver(() => checkForNewCall());
  observer.observe(document.body, {
    childList: true,
    subtree: true,
    characterData: true,
  });
}
